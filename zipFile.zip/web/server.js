// server.js — Boko AI Product Recommendations (embedded Shopify app backend)
// Multi-store: each shop installs via OAuth and gets its own stored session,
// so one deployment serves many stores. On uninstall we clean that shop's sessions.

import express from "express";
import { shopifyApp } from "@shopify/shopify-app-express";
import { SQLiteSessionStorage } from "@shopify/shopify-app-session-storage-sqlite";
import { LATEST_API_VERSION, DeliveryMethod } from "@shopify/shopify-api";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { recommend } from "./recommendations.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = parseInt(process.env.PORT || "3000", 10);

// Durable per-shop session storage. SQLite is fine on a host with a PERSISTENT disk
// (Render disk, Fly volume, a VPS). On ephemeral/serverless hosts swap for a
// Postgres/MySQL/Redis session storage adapter so sessions survive restarts.
const dbPath = process.env.SESSION_DB_PATH || path.join(__dirname, "database.sqlite");
const sessionStorage = new SQLiteSessionStorage(dbPath);

const shopify = shopifyApp({
  api: {
    apiKey: process.env.SHOPIFY_API_KEY,
    apiSecretKey: process.env.SHOPIFY_API_SECRET,
    scopes: (process.env.SCOPES || "read_products,read_orders").split(","),
    apiVersion: LATEST_API_VERSION,
    hostName: (process.env.HOST || "").replace(/^https?:\/\//, ""),
  },
  auth: { path: "/api/auth", callbackPath: "/api/auth/callback" },
  webhooks: { path: "/api/webhooks" },
  sessionStorage,
});

// On uninstall, remove all sessions for that shop so a future re-install is clean.
const webhookHandlers = {
  APP_UNINSTALLED: {
    deliveryMethod: DeliveryMethod.Http,
    callbackUrl: "/api/webhooks",
    callback: async (_topic, shop) => {
      try {
        const sessions = await sessionStorage.findSessionsByShop(shop);
        if (sessions && sessions.length) {
          await sessionStorage.deleteSessions(sessions.map((s) => s.id));
        }
        console.log(`[reco] cleaned sessions for uninstalled shop: ${shop}`);
      } catch (e) {
        console.error("[reco] uninstall cleanup failed:", e.message);
      }
    },
  },
};
shopify.api.webhooks.addHandlers(webhookHandlers);

const app = express();

// auth.callback() auto-registers the added webhooks for each shop on install.
app.get(shopify.config.auth.path, shopify.auth.begin());
app.get(shopify.config.auth.callbackPath, shopify.auth.callback(), shopify.redirectToShopifyOrAppRoot());
app.post(shopify.config.webhooks.path, shopify.processWebhooks({ webhookHandlers }));

app.use(express.json());

async function loadProducts(session, limit = 100) {
  const client = new shopify.api.clients.Graphql({ session });
  const query = `#graphql
    query Products($n: Int!) {
      products(first: $n, sortKey: BEST_SELLING) {
        edges { node {
          id title productType vendor
          featuredImage { url }
          variants(first: 1) { edges { node { id price } } }
          metafield(namespace: "custom", key: "views") { value }
          ordersMetafield: metafield(namespace: "custom", key: "orders") { value }
        } }
      }
    }`;
  const resp = await client.request(query, { variables: { n: limit } });
  const edges = (resp && resp.data && resp.data.products && resp.data.products.edges) || [];
  return edges.map((e, i) => {
    const n = e.node;
    const v = n.variants && n.variants.edges[0] && n.variants.edges[0].node;
    return {
      id: n.id,
      variantId: v && v.id,
      title: n.title,
      vendor: n.vendor,
      category: (n.productType || "").toLowerCase(),
      price: v ? parseFloat(v.price) : 0,
      img: (n.featuredImage && n.featuredImage.url) || "",
      orders: n.ordersMetafield ? parseInt(n.ordersMetafield.value, 10) : Math.max(0, limit - i) * 3,
      views: n.metafield ? parseInt(n.metafield.value, 10) : 0,
    };
  });
}

// App Proxy: storefront widget calls this (signed by Shopify)
app.get("/proxy/recommend", async (req, res) => {
  try {
    const session =
      (res.locals.shopify && res.locals.shopify.session) ||
      (await shopify.api.session.customAppSession(req.query.shop));
    
    const limit = Math.min(parseInt(req.query.limit || "8", 10), 24);
    const products = await loadProducts(session);
    const anchor = req.query.anchor ? products.find((p) => p.id.endsWith(req.query.anchor)) : null;
    const items = await recommend({ products, anchor, limit });
    res.set("Content-Type", "application/json");
    res.status(200).send(JSON.stringify({ type: "recommended", items }));
  } catch (e) {
    console.error("[reco] /proxy/recommend error:", e.message);
    res.status(200).send(JSON.stringify({ type: "recommended", items: [], error: e.message }));
  }
});

app.use("/api/*", shopify.validateAuthenticatedSession());

let SETTINGS = { perRow: 4, bundleDiscount: 10, tabs: ["purchased", "viewed", "upsell", "downsell"], title: "You might also like" };
app.get("/api/settings", (req, res) => res.json(SETTINGS));
app.post("/api/settings", (req, res) => { SETTINGS = { ...SETTINGS, ...req.body }; res.json(SETTINGS); });

app.use(shopify.cspHeaders());
app.use(express.static(path.join(__dirname, "frontend")));
app.use("/*", shopify.ensureInstalledOnShop(), (req, res) => {
  res.set("Content-Type", "text/html").send(
    fs.readFileSync(path.join(__dirname, "frontend", "index.html"))
  );
});

app.listen(PORT, () => console.log(`Boko Reco app listening on ${PORT}`));
